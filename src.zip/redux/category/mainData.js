const mainData = [
  {
    title: '외투',
    id: 1,
    imageUrl:
      'https://image.msscdn.net/images/goods_img/20200901/1576700/1576700_6_big.jpg',
  },
  {
    title: '상의',
    id: 2,
    imageUrl:
      'https://image.msscdn.net/images/goods_img/20210809/2054385/2054385_2_500.jpg',
  },
  {
    title: '하의',
    id: 3,
    imageUrl:
      'https://image.msscdn.net/images/goods_img/20191113/1224095/1224095_4_500.jpg',
  },
];

export default mainData;
