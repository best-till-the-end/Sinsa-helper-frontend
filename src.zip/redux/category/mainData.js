const mainData = [
  {
    title: 'outer',
    id: 1,
    imageUrl:
      'https://image.msscdn.net/images/goods_img/20200901/1576700/1576700_6_big.jpg',
  },
  {
    title: 'top',
    id: 2,
    imageUrl:
      'https://image.msscdn.net/images/goods_img/20210809/2054385/2054385_2_500.jpg',
  },
  {
    title: 'pants',
    id: 3,
    imageUrl:
      'https://image.msscdn.net/images/goods_img/20191113/1224095/1224095_4_500.jpg',
  },
];

export default mainData;
